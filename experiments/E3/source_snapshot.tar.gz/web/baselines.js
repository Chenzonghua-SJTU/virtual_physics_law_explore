'use strict';
const states = {queued:'排队等待',running:'正在探索',submitted:'已提交',error:'错误',stopped:'已停止',incomplete:'未完成',completed:'已结束'};
function element(tag, text, cls) {
  const el=document.createElement(tag);
  if(text!==undefined) el.textContent=text;
  if(cls) el.className=cls;
  return el;
}
const number=(value,digits=2)=>typeof value==='number'&&Number.isFinite(value)?value.toFixed(digits):'—';
function render(batch) {
  const section=element('section');
  const repeat=batch.id.endsWith('r02')?'R02':'R01';
  section.append(element('h2',`${batch.model} · ${repeat} · ${states[batch.status]||batch.status}`));
  section.append(element('div',batch.id,'batch-id'));
  const wrap=element('div',undefined,'table-wrap'), table=element('table');
  const head=element('tr');
  for(const title of ['世界','状态','本地总分','位置 RMSE','总耗时','输出 token / 轮','调用数','测试轨迹','消耗能量']) head.append(element('th',title));
  const thead=element('thead');thead.append(head);table.append(thead);
  const body=element('tbody');
  for(const row of batch.worlds){
    const tr=element('tr'), name=element('td'), link=element('a',row.world_id.replace('world_','世界 0'));
    link.href='/?run='+encodeURIComponent(row.run_id);name.append(link);tr.append(name);
    const status=element('td',states[row.status]||row.status,row.status==='submitted'?'submitted':(['running','queued'].includes(row.status)?'running':'failed'));
    if(row.reason&&row.status!=='submitted') status.append(element('span',row.reason,'reason'));
    tr.append(status);
    const rmse=row.evaluation_complete?row.independent_rmse?.position_rmse:null;
    const score=row.evaluation_complete?row.evaluation_score?.total:null;
    const error=typeof rmse==='number'&&Number.isFinite(rmse)?(rmse<0.001?rmse.toExponential(3):rmse.toFixed(4)):'—';
    const terminal=!['queued','running','starting','evaluating'].includes(row.status);
    const average=terminal&&row.calls>0&&row.conservative_reserved_tokens===0?row.completion_tokens/row.calls:null;
    const seconds=row.wall_seconds_including_evaluation;
    const rounded=Math.round(seconds);
    const duration=typeof seconds==='number'?`${Math.floor(rounded/60)}分${rounded%60}秒`:'—';
    for(const val of [number(score),error,duration,number(average,1),row.calls??0,row.n_test_trajectories??'—',number(row.energy_used,0)]) tr.append(element('td',String(val)));
    body.append(tr);
  }
  table.append(body);wrap.append(table);section.append(wrap);return section;
}
async function refresh(){
  try{
    const response=await fetch('/api/baselines');if(!response.ok)throw Error('HTTP '+response.status);
    const data=await response.json();
    const sorted=data.batches.sort((a,b)=>a.id.includes('qwen38')!==b.id.includes('qwen38')?(a.id.includes('qwen38')?-1:1):a.id.localeCompare(b.id));
    document.getElementById('batches').replaceChildren(...sorted.map(render));
    const rows=data.batches.flatMap(b=>b.worlds), completed=rows.filter(r=>r.evaluation_complete).length;
    document.getElementById('connection').textContent=`已完成独立评测 ${completed} / ${rows.length} · 更新于 ${new Date().toLocaleTimeString()} · 每 5 秒刷新`;
  }catch(e){document.getElementById('connection').textContent='连接暂时中断，保留上次结果，正在重试…';}
  setTimeout(refresh,5000);
}
refresh();
